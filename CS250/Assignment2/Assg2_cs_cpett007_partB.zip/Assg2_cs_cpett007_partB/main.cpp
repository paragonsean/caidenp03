#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <sstream>  // for string streams
#include <stdlib.h>
#include "candadites.h"
#include "openings.h"
#include "generalFunctions.h"


using namespace std;



int main()
{
    Menu();
    return 0;
}
