#include <iostream>

using namespace std;

int main()
{
    //same project without class or use of structs
    string s1name;
    string s2name;
    string s3name;
    string s4name;
    string s5name;
    int s1age;
    int s2age;
    int s3age;
    int s4age;
    int s5age;
    float s1gpa;
    float s2gpa;
    float s3gpa;
    float s4gpa;
    float s5gpa;
    string s1grade;
    string s2grade;
    string s3grade;
    string s4grade;
    string s5grade;

    cout << "enter student name: " << endl;
    cin >> s1name;
    cout << "enter student age: " << endl;
    cin >> s1age;
    cout << "enter student gpa: " << endl;
    cin >> s1gpa;
    cout << "enter student grade level: " << endl;
    cin >> s1grade;
    cout << "enter student name: " << endl;
    cin >> s2name;
    cout << "enter student age: " << endl;
    cin >> s2age;
    cout << "enter student gpa: " << endl;
    cin >> s2gpa;
    cout << "enter student grade level: " << endl;
    cin >> s2grade;
    cout << "enter student name: " << endl;
    cin >> s3name;
    cout << "enter student age: " << endl;
    cin >> s3age;
    cout << "enter student gpa: " << endl;
    cin >> s3gpa;
    cout << "enter student grade level: " << endl;
    cin >> s3grade;
    cout << "enter student name: " << endl;
    cin >> s4name;
    cout << "enter student age: " << endl;
    cin >> s4age;
    cout << "enter student gpa: " << endl;
    cin >> s4gpa;
    cout << "enter student grade level: " << endl;
    cin >> s4grade;
    cout << "enter student name: " << endl;
    cin >> s5name;
    cout << "enter student age: " << endl;
    cin >> s5age;
    cout << "enter student gpa: " << endl;
    cin >> s5gpa;
    cout << "enter student grade level: " << endl;
    cin >> s5grade;


    return 0;
}
