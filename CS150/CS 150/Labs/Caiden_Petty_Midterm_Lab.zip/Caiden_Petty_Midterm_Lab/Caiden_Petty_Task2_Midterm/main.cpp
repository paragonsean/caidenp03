///Caiden Petty 01204093
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{
    int i=1993;/// i is for the year, this makes it easy to display the year when the loop continues
    int y=0;/// y is for the years since 1993, this makes the formula usable
    double formula;///this will be what we set the formula equal to

    cout << "Quantity of paper recycled from 1993 to 2007" << endl;
    cout << "In thousands of tons." << endl;
    cout << "----------------------------------------------" << endl;
    cout << left << "year "
         << right << " paper recycled" << endl;
    while (i <= 2007)
    {


    formula = (-0.0013 * pow(y,4)) + (0.0513 * pow(y,3)) - (0.662 * pow(y,2)) + (4.128 * y) + 35.75;
    cout << i << right << "   " << fixed << showpoint << setprecision(4) << formula << endl;
     y++;
     i++;
    }
    return 0;
}
