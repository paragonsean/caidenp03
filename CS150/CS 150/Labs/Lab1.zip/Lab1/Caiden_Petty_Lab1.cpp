#include <iostream>

using namespace std;

int main()
{
    cout << "Name of source file: Caiden_Petty_Lab1.cpp" << endl
         << "Student Name: Caiden Petty" << endl
         << "Student UIN: 01204093" << endl
         << "Date: September 1, 2021" << endl
         << "Lab CRN: 10232" << endl;
}
